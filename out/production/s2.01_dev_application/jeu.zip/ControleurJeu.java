/**
 * @author CAUVIN Pierre, MONTAGNE Aubin, DELPECHE Nicolas, GUELLE Clément BOUQUET Jules, YACHIR Yanis, ROUGEOLLE Henri
 */
package psyche.jeu;

import psyche.Controleur;
import psyche.jeu.metier.Route;
import psyche.jeu.metier.Couleur;
import psyche.jeu.metier.Metier;
import psyche.jeu.metier.Mine;
import psyche.jeu.vue.*;

import java.util.List;

public class ControleurJeu {
	/*--------------*/
	/* Données */
	/*--------------*/

	private final Metier metier;
	private final FrameCarte frameCarte;
	private final Controleur ctrl;

	private PanelCarte panelCarte;

	/*--------------*/
	/* Méthodes */
	/*--------------*/

	/**
	 * Constructeur de Controleur
	 */

	public ControleurJeu(Controleur ctrl) {
		this.ctrl = ctrl;
		this.metier = new Metier();
		this.frameCarte = new FrameCarte(this);
		this.panelCarte = new PanelCarte(this);
	}

	public Couleur getCouleur(String couleur) {
		for (Couleur c : Couleur.values()) {
			if (c.name().equals(couleur.toUpperCase())) {
				return c;
			}
		}
		return null;
	}

	public Mine getMine(int i) {
		return this.metier.getMine(i);
	}

	// public Mine getMine(Couleur couleur, int point)
	// {
	// return this.metier.getMine(couleur, point);
	// }

	/**
	 * Renvoie la liste des Mines
	 */
	public List<Mine> getMines() {
		return this.metier.getMines();
	}

	/**
	 * Renvoie la liste des Routes
	 */
	public List<Route> getRoutes() {
		return this.metier.getRoutes();
	}

	/**
	 * Renvoie une liste de Routes liées à une mine
	 *
	 * @param mine
	 * @return List<Route> Nom de la mine
	 */
	public List<Route> getRoute(Mine mine) {
		return mine.getRoutes();
	}

	/**
	 * Met à jour l'IHM
	 */
	public void majIHM() {
		this.frameCarte.getPanelCarte().repaint();
	}

	public Mine getMineIndice(int x, int y) {
		return metier.getMineIndice(x, y);
	}

	/*------------*/
	/* Fichiers */
	/*------------*/

	/**
	 * Renvoie le chemin d'accès du fichier d'où charger les données
	 */
	public String getFichierCharger() {
		return this.metier.getFichierCharger();
	}

	/**
	 * Définit le chemin d'accès du fichier
	 *
	 * @param path
	 *             Le chemin d'accès à définir.
	 */
	public void setFichierCharger(String path) {
		this.metier.setFichierCharger(path);
		this.majIHM();
	}

}
