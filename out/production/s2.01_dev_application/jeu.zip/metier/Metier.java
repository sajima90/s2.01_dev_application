/**
 * @author Groupe 4 SAE2.01 : Guelle Clément, Cauvin Pierre, Montagne Aubin, Delpech Nicolas
 * 							  Bouquet Jules, Rougeolle Henri, Yachir Yanis
 * La classe Metier gère les opérations liées aux mines et aux routes.
 */
package psyche.jeu.metier;

import psyche.jeu.metier.Mine;
import psyche.jeu.metier.Route;
import psyche.jeu.metier.Couleur;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Metier {
	/*--------------*/
	/* Données */
	/*--------------*/

	private final List<Mine> mines;
	private final List<Route> routes;

	private GestionFichier gestionFichier = new GestionFichier(this);

	/*--------------*/
	/* Instructions */
	/*--------------*/

	/**
	 * Constructeur de la classe Metier.
	 * Initialise les listes de mines et de routes.
	 */
	public Metier() {
		this.mines = new ArrayList<>();
		this.routes = new ArrayList<>();
	}

	/*------------*/
	/* Méthodes */
	/*------------*/

	/*------*/
	/* Get */
	/*------*/

	/**
	 * Renvoie le fichier chargé
	 *
	 * @return Le chemin du fichier chargé sous forme de String
	 */
	public String getFichierCharger() {
		return this.gestionFichier.getFicherCharger();
	}

	/**
	 * Récupère une mine précise selon son id
	 * 
	 * @param id
	 * @return Une mine
	 */
	public Mine getMine(int id) {
		for (Mine mine : this.mines)
			if (mine.getId() == id)
				return mine;

		return null;
	}

	/**
	 * Récupère la liste de toutes les mines.
	 *
	 * @return La liste des mines.
	 */
	public List<Mine> getMines() {
		return this.mines;
	}

	/**
	 * Récupère la liste de toutes les routes.
	 *
	 * @return La liste des routes.
	 */
	public List<Route> getRoutes() {
		return this.routes;
	}

	public void resetId() {
		Mine.resetId();
	}

	public Mine getMineIndice(int x, int y) {
		for (Mine mine : this.mines)
			if (mine.getX() == x && mine.getY() == y)
				return mine;

		return null;
	}

	public void setFichierCharger(String path) {
		this.gestionFichier.setFichierCharger(path);
	}

	public Mine ajouterMine(int x, int y, int point, Couleur couleur) {

		if (x < 0 || x > 1000 || y < 0 || y > 800) {
			JOptionPane.showMessageDialog(null, "Les coordonnées ne sont pas valides", "Erreur",
					JOptionPane.ERROR_MESSAGE);
			return null;
		}

		Mine mine = Mine.creerMine(x, y, point, couleur);
		System.out.println(mine);
		mines.add(mine);

		return mine;
	}

	public Route ajouterRoute(Mine depart, Mine arrivee, int troncons) {

		if (!estPossibleRoute(depart, arrivee, troncons)) {
			JOptionPane.showMessageDialog(null, "L'route existe déjà", "Erreur", JOptionPane.ERROR_MESSAGE);
			return null;
		}

		Route route = Route.creerRoute(depart, arrivee, troncons);
		routes.add(route);

		depart.addRoute(route);
		arrivee.addRoute(route);

		return route;
	}

	public boolean estPossibleRoute(Mine depart, Mine arrivee, int troncons) {
		for (Route route : this.routes)
			if (route.getDepart().equals(depart) && route.getArrivee().equals(arrivee))
				return false;

		for (Route route : this.routes)
			if (route.getDepart().equals(arrivee) && route.getArrivee().equals(depart))
				return false;

		if (troncons < 1 || troncons > 2) {
			JOptionPane.showMessageDialog(null, "Nombre de tronçon invalide", "Erreur", JOptionPane.ERROR_MESSAGE);
			return false;

		}

		return true;

	}

	public String toString() {
		return "\n\nMetier{ \n" + "MINE : \n" + mines + "\n\nROUTES : \n" + routes;
	}

}
