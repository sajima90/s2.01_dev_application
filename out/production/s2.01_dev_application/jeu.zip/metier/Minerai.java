package psyche.jeu.metier;

public enum Minerai 
{
    Aluminium (Al);
    Argent (Ag);
    OR;
    Cobalt;
    Fer;
    Nickel;
    Platine;
    Titane;
}
