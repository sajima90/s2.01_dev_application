package psyche.jeu.metier;

import psyche.jeu.metier.Metier;

import javax.swing.*;
import java.io.*;

public class GestionFichier {
	private String fichierCharger = "/home/saji/developpement/SAE 2.01/AppFinal/psyche/theme/Map.txt";

	private final Metier metier;

	public GestionFichier(Metier metier) {
		this.metier = metier;
	}

	public String getFicherCharger() {
		return this.fichierCharger;
	}

	public void setFichierCharger(String path) {
		this.fichierCharger = path;
		this.chargerMinesRoutes(path);
	}

	private void chargerMinesRoutes(String path) {
		if (path == null || path.isEmpty()) {
			return;
		}

		try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path)))) {
			if (!this.metier.getRoutes().isEmpty() && !this.metier.getMines().isEmpty()) {
				this.metier.getMines().clear();
				this.metier.getRoutes().clear();
				this.metier.resetId();
			}

			String ligne;
			boolean lireMines = false;
			boolean lireRoutes = false;

			while ((ligne = reader.readLine()) != null) {
				if (ligne.equals("[Mines] :")) {
					lireMines = true;
					lireRoutes = false;
					continue;
				} else if (ligne.equals("[Routes] :")) {
					lireRoutes = true;
					lireMines = false;
					continue;
				}

				if (lireMines) {
					if (ligne.equals("---------------------------------"))
						continue;
					String[] mine = ligne.split(",");
					if (mine.length == 6) {
						try {
							int id = Integer.parseInt(mine[0].trim());
							String nom = mine[1].trim();
							int x = Integer.parseInt(mine[2].trim());
							int y = Integer.parseInt(mine[3].trim());
							Couleur couleur = Couleur.valueOf(mine[4].trim());
							int point = Integer.parseInt(mine[5].trim());
							this.metier.ajouterMine(x, y, point, couleur);
						} catch (NumberFormatException e) {
							System.err.println("Erreur de format pour les coordonnées : " + ligne);
						}
					}
				} else if (lireRoutes) {
					if (ligne.equals("---------------------------------"))
						continue;
					String[] route = ligne.split(",");
					if (route.length == 3) {
						String routeDepart = route[0].trim();
						String routeArrivee = route[1].trim();
						try {
							int nombreTroncons = Integer.parseInt(route[2].trim());
							Mine depart = this.metier.getMine(Integer.parseInt(routeDepart));
							Mine arrivee = this.metier.getMine(Integer.parseInt(routeArrivee));
							this.metier.ajouterRoute(depart, arrivee, nombreTroncons);
						} catch (NumberFormatException e) {
							System.err.println("Erreur de format pour le nombre de tronçons : " + ligne);
						}
					}
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
