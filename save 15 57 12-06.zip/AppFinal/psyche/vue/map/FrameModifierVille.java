/**
 * @author CAUVIN Pierre, AUBIN Montagne, DELPECHE Nicolas, GUELLE Clément
 * Cette classe gère les routes.
 */
package psyche.vue.map;

import psyche.Controleur;
import psyche.metier.map.Mine;
import psyche.metier.minerai.Minerai;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

public class FrameModifierVille extends JFrame implements ActionListener, ItemListener
{
	private Controleur ctrl;

	private JLabel     coul;
	private JLabel     point;
	private JLabel     coordX;
	private JLabel     coordY;

	private JTextField txtCoul;
	private JTextField txtPoint;
	private JTextField txtCoordX;
	private JTextField txtCoordY;

	private JButton btnModifier;

	private JComboBox<Minerai> jcbDeroulanteMinerai;
	private JComboBox<String>  jcbDeroulantePoint;

	public FrameModifierVille(Controleur ctrl)
	{

		this.ctrl = ctrl;

		this.setTitle("Modifier Mine");
		this.setSize(300, 200);
		this.setLocation(150, 150);


		this.setVisible(true);


		this.setLayout(new GridLayout(5, 2, 0, 10));



		/* ----------------------------------  */
		/*       CRÉATION DES COMPOSANTS       */
		/* ----------------------------------  */


		String[] tabPoint = new String[] {"1","2","3","4","5"};


		this.jcbDeroulanteMinerai = new JComboBox<>(Minerai.values());
		this.jcbDeroulantePoint   = new JComboBox<>(tabPoint);


		this.coul       = new JLabel("Couleur     : ");
		this.coul.setBackground(Color.lightGray);
		this.coul.setOpaque(true);

		this.point       = new JLabel("Point     : ");
		this.point.setBackground(Color.lightGray);
		this.point.setOpaque(true);

		this.coordX    = new JLabel("Coord X : ");
		this.coordX.setBackground(Color.lightGray);
		this.coordX.setOpaque(true);

		this.coordY    = new JLabel("Coord Y : ");
		this.coordY.setBackground(Color.lightGray);
		this.coordY.setOpaque(true);

		this.txtCoul    = new JTextField(20);
		this.txtCoul.setEnabled(false);
		this.txtCoul.setBackground((Color.lightGray));

		this.txtCoordX = new JTextField(20);
		this.txtCoordX.setEnabled(false);
		this.txtCoordX.setBackground((Color.lightGray));

		this.txtCoordY = new JTextField(20);
		this.txtCoordY.setEnabled(false);
		this.txtCoordY.setBackground((Color.lightGray));


		this.btnModifier = new JButton("Modifier");
		this.btnModifier.setBackground(Color.WHITE);


		/* ----------------------------------  */
		/*    POSITIONNEMENT DES COMPOSANTS    */
		/* ----------------------------------  */


		this.add(this.jcbDeroulanteMinerai);
		this.add(this.jcbDeroulantePoint);

		this.add(this.coul);
		this.add(this.txtCoul);

		this.add(this.point);
		this.add(this.txtPoint);

		this.add(this.coordX);
		this.add(this.txtCoordX);

		this.add(this.coordY);
		this.add(this.txtCoordY);

		this.add(new JLabel());
		this.add(this.btnModifier);



		/* ----------------------------------  */
		/*      ACTIVATION DES COMPOSANTS      */
		/* ----------------------------------  */


		this.jcbDeroulanteMinerai.addItemListener(this);
		this.jcbDeroulantePoint  .addItemListener(this);

		this.txtCoul    .addActionListener(this);
		this.txtPoint   .addActionListener(this);
		this.txtCoordX  .addActionListener(this);
		this.txtCoordY  .addActionListener(this);
		this.btnModifier.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{

		Integer coordX = null;
		Integer coordY = null;

		if (e.getSource() == this.btnModifier)
		{
			try
			{
				coordX = Integer.parseInt(this.txtCoordX.getText());
				coordY = Integer.parseInt(this.txtCoordY.getText());
			}
			catch ( NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(this, "Erreur pour la saisie des coordonnées", "Erreur", JOptionPane.ERROR_MESSAGE);
			}


			if ( this.jcbDeroulanteMinerai.getSelectedItem() != null && this.txtCoul.getText() != null && coordX != null && coordY != null && this.jcbDeroulantePoint.getSelectedItem() != null && this.txtPoint.getText() != null )
			{
				System.out.println("couleur : " + this.jcbDeroulanteMinerai.getSelectedItem() + "Point " + this.jcbDeroulantePoint.getSelectedItem() + " coordX : " + coordX + " coordY : " + coordY);
				this.ctrl.modifierMine( coordX, coordY, this.ctrl.getCouleur(this.jcbDeroulanteMinerai.getSelectedItem().toString()), (Integer) this.jcbDeroulantePoint.getSelectedItem());
			}
		}
	}


	public void itemStateChanged(ItemEvent e)
	{
		if (e.getSource() == this.jcbDeroulanteMinerai && this.jcbDeroulanteMinerai.getSelectedIndex() != 0 && e.getSource() == this.jcbDeroulantePoint && this.jcbDeroulantePoint.getSelectedIndex() != 0)
		{
			this.txtCoul.setText(this.jcbDeroulanteMinerai.getSelectedItem().toString());
			this.txtCoul.setBackground((Color.WHITE));

			this.txtPoint.setText(this.jcbDeroulantePoint.getSelectedItem().toString());
			this.txtPoint.setBackground((Color.WHITE));

			this.txtCoordX.setText(String.valueOf(this.ctrl.getMineParMineraiPoint(this.ctrl.getCouleur((String) this.jcbDeroulanteMinerai.getSelectedItem()), (Integer) this.jcbDeroulantePoint.getSelectedItem()).getX()));
			this.txtCoordX.setEnabled(true);
			this.txtCoordX.setBackground((Color.WHITE));

			this.txtCoordY.setText(String.valueOf(this.ctrl.getMineParMineraiPoint(this.ctrl.getCouleur((String) this.jcbDeroulanteMinerai.getSelectedItem()), (Integer) this.jcbDeroulantePoint.getSelectedItem()).getY()));
			this.txtCoordY.setEnabled(true);
			this.txtCoordY.setBackground((Color.WHITE));
		}
		else
		{
			this.txtCoul.setText("");
			this.txtCoul.setBackground(Color.lightGray);

			this.txtPoint.setText("");
			this.txtPoint.setBackground(Color.lightGray);

			this.txtCoordX.setText("");
			this.txtCoordX.setEnabled(false);
			this.txtCoordX.setBackground(Color.lightGray);

			this.txtCoordY.setText("");
			this.txtCoordY.setEnabled(false);
			this.txtCoordY.setBackground(Color.lightGray);
		}
	}

}

