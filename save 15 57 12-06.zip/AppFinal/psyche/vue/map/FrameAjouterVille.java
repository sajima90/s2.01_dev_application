/**
 * @author CAUVIN Pierre, AUBIN Montagne, DELPECHE Nicolas, GUELLE Clément
 * Cette classe gère les routes.
 */
package psyche.vue.map;

import psyche.Controleur;
import psyche.metier.minerai.Couleur;
import psyche.metier.minerai.Minerai;
import psyche.metier.map.Mine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class FrameAjouterVille extends JFrame implements ActionListener, ItemListener
{
	private Controleur ctrl;

	private JPanel panelGauche;
	private JPanel panelDroite;

	private JTable                tblDonnes;
	private GrlDonneesModelVille  donnesTableau;

	private JButton    btnAjouter;

	private JTextField txtcordX;
	private JTextField txtcordY;

	private JLabel lblVisu;
	private JLabel lblcordX;
	private JLabel lblcordY;

	private JComboBox<Couleur> jcbDeroulanteCouleur;
	private JComboBox<String>  jcbDeroulantePoint;

	private String[] tabPointMine1;
	private String[] tabPointMine2;
	private String[] tabPointMine3;



	public FrameAjouterVille(Controleur ctrl)
	{

		this.setTitle("Ajouter Mine");
		this.setSize(600, 300);
		this.setLayout(new GridLayout(1,2,10,20));
		this.getContentPane().setBackground(Color.gray);

		this.ctrl  = ctrl;

		JScrollPane spTableau;

		/*-------------------------*/
		/* Création des composants */
		/*-------------------------*/

		/*-------------------------------*/
		/*         Point des mines       */
		/*-------------------------------*/
		tabPointMine1 = new String[] {"1","2","3","4","5"};	//or  , rouge , marron
		tabPointMine2 = new String[] {"2","3","4","6","8"};	//bleu, vert
		tabPointMine3 = new String[] {"0","1","2","3","4"}; //gris


		Font font = new Font("Roboto Slab",Font.BOLD,10);

		this.jcbDeroulanteCouleur = new JComboBox<>(Couleur.values());
		this.jcbDeroulantePoint   = new JComboBox<>(tabPointMine1);

		this.panelGauche = new JPanel(new BorderLayout());
		this.panelDroite = new JPanel(new GridLayout(5,2,0,10));

		this.donnesTableau = new GrlDonneesModelVille(this.ctrl);
		this.tblDonnes     = new JTable(this.donnesTableau);
		this.tblDonnes.setFillsViewportHeight(true);

		spTableau = new JScrollPane(this.tblDonnes);

		this.lblVisu = new JLabel("Visualisation des mines");


		/* Création des Labels et leurs couleurs */

		this.lblcordX = new JLabel("CoordX   :");
		this.lblcordX.setBackground(Color.lightGray);
		this.lblcordX.setFont(new Font("Outfit", Font.BOLD, 12));
		this.lblcordX.setOpaque(true);

		this.lblcordY = new JLabel("CoordY   :");
		this.lblcordY.setBackground(Color.lightGray);
		this.lblcordY.setFont(new Font("Outfit", Font.BOLD, 12));
		this.lblcordY.setOpaque(true);

		this.txtcordX = new JTextField();
		this.txtcordX.setFont(font);

		this.txtcordY = new JTextField();
		this.txtcordY.setFont(font);

		this.btnAjouter = new JButton("Ajouter");
		this.btnAjouter.setBackground(Color.WHITE);

		/*-------------------------------*/
		/* Positionnement des composants */
		/*-------------------------------*/

		this.panelGauche.add(spTableau   , BorderLayout.CENTER);
		this.panelGauche.add(this.lblVisu, BorderLayout.SOUTH);

		this.panelDroite.add(this.lblcordX);
		this.panelDroite.add(this.txtcordX);

		this.panelDroite.add(this.lblcordY);
		this.panelDroite.add(this.txtcordY);

		this.panelDroite.add(this.jcbDeroulanteCouleur);
		this.panelDroite.add(this.jcbDeroulantePoint);


		this.panelDroite.add(new JLabel());
		this.panelDroite.add(this.btnAjouter);

		this.add(this.panelGauche);
		this.add(this.panelDroite);


		/*-------------------------------*/
		/*   Activation des composants   */
		/*-------------------------------*/

		this.jcbDeroulanteCouleur.addItemListener(this);
		this.jcbDeroulantePoint  .addItemListener(this);

		this.btnAjouter.addActionListener(this);
		this.txtcordX  .addActionListener(this);
		this.txtcordY  .addActionListener(this);


		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnAjouter)
		{
			String cordX = this.txtcordX.getText();
			String cordY = this.txtcordY.getText();


			if (cordX == null && cordY == null)
				JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs", "Erreur", JOptionPane.ERROR_MESSAGE);

			try
			{
				cordX = String.valueOf(Integer.parseInt(cordX));
				cordY = String.valueOf(Integer.parseInt(cordY));
			}
			catch (NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(this, "Erreur pour la saisie des coordonnées", "Erreur", JOptionPane.ERROR_MESSAGE);
				return;
			}

			this.ctrl    .ajouterMine( Integer.parseInt(cordX), Integer.parseInt(cordY), Integer.parseInt(this.jcbDeroulantePoint.getSelectedItem().toString()), Couleur.valueOf(this.jcbDeroulanteCouleur.getSelectedItem().toString()) );
			this.txtcordX.setText("");
			this.txtcordY.setText("");
			this.ctrl    .majIHM();

			this.majIHM();
		}
	}

	public void majIHM()
	{
		this.tblDonnes.setModel(new GrlDonneesModelVille(this.ctrl));
	}


	public void itemStateChanged(ItemEvent e)
	{

		if ( e.getSource() == this.jcbDeroulanteCouleur)
		{

			for (Mine mine : ctrl.getMines())
			{
				if (mine.getPoint() == Integer.parseInt(this.jcbDeroulantePoint.getSelectedItem().toString()) && mine.getCouleur().name().equals(this.jcbDeroulanteCouleur.getSelectedItem().toString()))
				{
					this.jcbDeroulanteCouleur.setSelectedIndex(0);

				}
			}

			switch (this.jcbDeroulanteCouleur.getSelectedItem().toString())
			{
				case "VERT", "BLEU_CLAIR" ->
				{
					this.jcbDeroulantePoint.setModel(new DefaultComboBoxModel<>(tabPointMine2));
				}
				case "GRIS" ->
				{
					this.jcbDeroulantePoint.setModel(new DefaultComboBoxModel<>(tabPointMine3));
				}

				default -> {this.jcbDeroulantePoint.setModel(new DefaultComboBoxModel<>(tabPointMine1));
				}
			}

		}

//		if (e.getSource() == this.jcbDeroulanteCouleur )
//		{
//
//			this.txtCoordX.setText(String.valueOf(this.ctrl.getMine(this.jcbDeroulante.getSelectedItem().toString()).getX()));
//			this.txtCoordX.setEnabled(true);
//			this.txtCoordX.setBackground((Color.WHITE));
//
//			this.txtCoordY.setText(String.valueOf(this.ctrl.getMine(this.jcbDeroulante.getSelectedItem().toString()).getY()));
//			this.txtCoordY.setEnabled(true);
//			this.txtCoordY.setBackground((Color.WHITE));
//
//			this.txtCoordX.setText(String.valueOf(this.ctrl.getMine(this.jcbDeroulante.getSelectedItem().toString()).getX()));
//			this.txtCoordY.setText(String.valueOf(this.ctrl.getMine(this.jcbDeroulante.getSelectedItem().toString()).getY()));
//		}
//		else
//		{
//
//			this.txtCoordX.setText("");
//			this.txtCoordX.setEnabled(false);
//			this.txtCoordX.setBackground(Color.lightGray);
//
//			this.txtCoordY.setText("");
//			this.txtCoordY.setEnabled(false);
//			this.txtCoordY.setBackground(Color.lightGray);
//		}

	}
}