/**
 * @author  Pierre Cauvin, Clément Guelle, Aubin Montagne, Nicolas Delpech
 *          Henri Rougeolle, Yanis Yachir, Jules Bouquet
 *
 */

package psyche.metier;

public class Jeu
{
	// 1 plateau principal
	// 2 plateaux indiv
	
}
