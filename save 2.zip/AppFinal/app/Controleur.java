package app;

public class Controleur
{

		public static void main(String[] args)
	{
		new Controleur();
	}


}
