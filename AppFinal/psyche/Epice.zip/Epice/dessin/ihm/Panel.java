package dessin.ihm;

import javax.swing.*;

import dessin.Controleur;

import java.awt.*;
import java.awt.event.ActionEvent;

public class Panel extends JPanel 
{
	private Controleur ctrl;
	private Graphics2D g2;

	private Image imgFond;

	private JLabel[][] tabEpice;
	private JLabel[]   tabPiece;

	public Panel(Controleur ctrl)
	{

		this.ctrl = ctrl;

		this.imgFond = getToolkit().getImage(this.ctrl.getImageFond());


		this.setLayout(null);

		int[][] coordsEpice = { {  64, 20  }, { 116,  20 }, { 167,  20 }, { 218,  20 }, { 270,  20 }, { 321,  20 }, { 373,  20 }, { 424,  20 },
                                {  64, 69  }, { 116,  69 }, { 167,  69 }, { 218,  69 }, { 270,  69 }, { 321,  69 }, { 373,  69 }, { 424,  69 },
                                {  64, 118 }, { 116, 118 }, { 167, 118 }, { 218, 118 }, { 270, 118 }, { 321, 118 }, { 373, 118 }, { 424, 118 },
                                {  64, 167 }, { 116, 224 }, { 167, 167 }, { 218, 167 }, { 270, 167 }, { 321, 167 }, { 373, 167 }, { 424, 167 }};

        // Coordonnées pour les pièces 
        int[] coordsPiece = { 64, 116, 167, 218, 270, 321, 373, 424, 763 };



		// création des composants;


		this.tabEpice = new JLabel[4][8];                       // A CHANGE LES VALEURS EN DUR
		this.tabPiece = new JLabel[8];                          // A CHANGE LES VALEURS EN DUR

		int indexEpice = 0;
		for (int lig = 0; lig <= this.tabEpice.length - 1; lig++)
		{
			int compteurEpice = 2-lig;

			for (int col = 0; col <= this.tabEpice[lig].length - 1; col++)
			{

				this.tabEpice[lig][col] = new JLabel();
				this.tabEpice[lig][col].setBounds(coordsEpice[indexEpice][0], coordsEpice[indexEpice][1], 100, 100); // Positionnement manuel

				if ( ctrl.getEpice(compteurEpice) != null )
				{
					Icon img = new ImageIcon(ctrl.getEpice(compteurEpice));

					this.tabEpice[lig][col].setIcon(img);
					this.tabEpice[lig][col].setOpaque(false);
				}
				
				compteurEpice+=3;
				indexEpice   ++ ;
			}

		}


		System.out.println(ctrl.getNbPiece());

		for (int indice = 0; indice <= ctrl.getNbPiece(); indice++)
		{
			Icon img = new ImageIcon(ctrl.getPiece());

			this.tabPiece[indice] = new JLabel();
			this.tabPiece[indice].setBounds(coordsPiece[indice],266,  100, 100);
			this.tabPiece[indice].setIcon(img);
			this.tabPiece[indice].setOpaque(false);

		}



		// positionnement des composants
		

		for (int lig = 0; lig < tabEpice.length; lig++)
			for (int col = 0; col < tabEpice[lig].length; col++)
			{
				this.add(this.tabEpice[lig][col]);
			}

		for (int indice = 0; indice < ctrl.getNbPiece(); indice++)
		{
			this.add(this.tabPiece[indice]);
		}

	}

	public void actionPerformed(ActionEvent evt)
	{
		this.repaint();
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		g2 = (Graphics2D) g;

		// Ajout de l'image du fond
		g2.drawImage(imgFond, 0, 0,this.getWidth(), this.getHeight(), this);
	}

}